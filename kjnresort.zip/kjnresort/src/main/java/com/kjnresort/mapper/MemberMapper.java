package com.kjnresort.mapper;

import com.kjnresort.domain.MemberVO;

public interface MemberMapper {
	
	public MemberVO read(String userid);
}
