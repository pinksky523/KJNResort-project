package com.kjnresort.service;

public interface SampleTxService {
	public void addData(String value);
}
